// Exports the "importcss" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/importcss')
//   ES2015:
//     import 'tinymce/plugins/importcss'
require('./plugin.js');