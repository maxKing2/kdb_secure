// Exports the "inlite" theme for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/themes/inlite')
//   ES2015:
//     import 'tinymce/themes/inlite'
require('./theme.js');